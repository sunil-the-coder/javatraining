package com.examples.model;

public enum ProdCategory {
	A,B,C
}
